﻿using System.Collections;
using System.Collections.Generic;
using System.Xml;
using UnityEngine;

public class Slot{
    public Color backColor;
    public Color frontColor;
    public int[,] matrix = new int[64, 36];
    public List<SlotUndo> undoList = new List<SlotUndo>();
    public int templateId = 1;

    public Slot()
    {
        backColor = new Color(0.5f, 0.5f, 0.7f);
        frontColor = new Color(0.8f, 0.8f, 0.9f);
        for(int x = 1; x <= 64; x++)
        {
            for(int y = 1; y <= 36; y++)
            {
                matrix[x - 1, y - 1] = 0;
            }
        }
    }

    public float BackColorBrightness
    {
        get
        {
            return backColor.r + backColor.g + backColor.b;
        }
    }

    public void saveMatrix()
    {
        #region old
        /*if (undoList.Count < GameStatus.maxUndoCount)
        {
            undoList.Add(new SlotUndo());
        }
        else
        {
            undoList.RemoveAt(0);
            undoList.Add(new SlotUndo());
        }
        for(int x = 1; x <= 64; x++)
        {
            for(int y = 1; y <= 36; y++)
            {
                undoList[undoList.Count - 1].matrix[x - 1, y - 1] = matrix[x - 1, y - 1];
            }
        }*/
        #endregion
        //考虑到快速交替按下两指会触发此函数；
        //而且在已经画过的位置重复画也会触发次函数；
        //所以必须判断一下前后矩阵是否相同，如果相同，则删掉当前矩阵。
        int sameCount = 0;
        undoList.Add(new SlotUndo());
        if (undoList.Count > 1)
        {
            for (int x = 1; x <= 64; x++)
            {
                for (int y = 1; y <= 36; y++)
                {
                    if(matrix[x - 1, y - 1] == undoList[undoList.Count - 2].matrix[x - 1, y - 1])
                    {
                        sameCount += 1;
                    }
                    undoList[undoList.Count - 1].matrix[x - 1, y - 1] = matrix[x - 1, y - 1];
                }
            }
            if(sameCount == 64 * 36)
            {
                //GameStatus.textBulletList.Add(new TextBullet("count=" + undoList.Count, GameStatus.getBulletTextRect(7), Color.black));
                undoList.RemoveAt(undoList.Count - 1);
            }
        }
        //这里之所以冗余是为了大幅度提高性能
        else//第一个撤销档是保底的，不能被undo
        {
            for (int x = 1; x <= 64; x++)
            {
                for (int y = 1; y <= 36; y++)
                {
                    undoList[undoList.Count - 1].matrix[x - 1, y - 1] = matrix[x - 1, y - 1];
                }
            }
        }
        if(undoList.Count > GameStatus.maxUndoCount+1)
        {
            undoList.RemoveAt(0);
        }
    }

    public void undo()
    {
        if(undoList.Count > 1)
        {
            for (int x = 1; x <= 64; x++)
            {
                for (int y = 1; y <= 36; y++)
                {
                    matrix[x - 1, y - 1] = undoList[undoList.Count - 2].matrix[x - 1, y - 1];
                }
            }
            undoList.RemoveAt(undoList.Count - 1);
        }
        GameStatus.generateFrontTex();
    }

    public bool isCloseColor()
    {
        if(Mathf.Sqrt((backColor.r - frontColor.r) * (backColor.r - frontColor.r) + 
            (backColor.g - frontColor.g)* (backColor.g - frontColor.g) + 
            (backColor.b - frontColor.b)* (backColor.b - frontColor.b)) < 0.1f)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public string SlotXml
    {
        get
        {
            string str1 = "<slot>";
            int bitCompressedInt;
            str1 += "<backColor><r>" + Mathf.RoundToInt(backColor.r * 255) + "</r><g>" + Mathf.RoundToInt(backColor.g * 255) +
                "</g><b>" + Mathf.RoundToInt(backColor.b * 255) + "</b></backColor>";
            str1 += "<frontColor><r>" + Mathf.RoundToInt(frontColor.r * 255) + "</r><g>" + Mathf.RoundToInt(frontColor.g * 255) +
                "</g><b>" + Mathf.RoundToInt(frontColor.b * 255) + "</b></frontColor>";
            str1 += "<templateId>" + templateId + "</templateId>";
            /*for(int x = 1; x <= 64; x++)
            {
                for(int y = 1; y <= 36; y++)
                {
                    str1 += "<e>" + matrix[x - 1, y - 1] + "</e>";
                }
            }*/
            for (int y = 1; y <= 36; y++)
            {
                bitCompressedInt = 0;
                for(int x = 1; x <= 32; x++)
                {
                    bitCompressedInt |= matrix[x - 1, y - 1] << (x - 1);
                }
                str1 += "<e>" + bitCompressedInt + "</e>";
                bitCompressedInt = 0;
                for (int x = 33; x <= 64; x++)
                {
                    bitCompressedInt |= matrix[x - 1, y - 1] << (x - 33);
                }
                str1 += "<e>" + bitCompressedInt + "</e>";
            }

            str1 += "</slot>";
            return str1;
        }
    }

    public void loadFromXml(string xmlStr)
    {
        XmlDocument xd1 = new XmlDocument();
        XmlDocument xd2 = new XmlDocument();
        int bitCompressedInt;
        xd1.LoadXml(xmlStr);
        //Debug.Log("loading...");
        try
        {
            xd2.LoadXml(xd1.GetElementsByTagName("backColor")[0].OuterXml);
            backColor = new Color(int.Parse(xd2.GetElementsByTagName("r")[0].InnerText) / 255f,
                int.Parse(xd2.GetElementsByTagName("g")[0].InnerText) / 255f, int.Parse(xd2.GetElementsByTagName("b")[0].InnerText) / 255f);
            xd2.LoadXml(xd1.GetElementsByTagName("frontColor")[0].OuterXml);
            frontColor = new Color(int.Parse(xd2.GetElementsByTagName("r")[0].InnerText) / 255f,
                int.Parse(xd2.GetElementsByTagName("g")[0].InnerText) / 255f, int.Parse(xd2.GetElementsByTagName("b")[0].InnerText) / 255f);
            templateId = int.Parse(xd1.GetElementsByTagName("templateId")[0].InnerText);
            /*for(int x = 1; x <= 64; x++)
            {
                for(int y = 1; y <= 36; y++)
                {
                    matrix[x - 1, y - 1] = int.Parse(xd1.GetElementsByTagName("e")[(x - 1) * 36 + y - 1].InnerText);
                }
            }
            string str1 = "";
            for (int x = 1; x <= 64; x++)
            {
                for (int y = 1; y <= 36; y++)
                {
                    str1 += matrix[x - 1, y - 1];
                }
            }
            Debug.Log(str1);*/
            for (int y = 1; y <= 36; y++)
            {
                bitCompressedInt = int.Parse(xd1.GetElementsByTagName("e")[(y - 1) * 2].InnerText);
                for(int x = 1; x <= 32; x++)
                {
                    matrix[x - 1, y - 1] = (bitCompressedInt & (1 << (x - 1))) >> (x - 1);
                    if (matrix[x - 1, y - 1]<0 || matrix[x - 1, y - 1] > 1)
                    {
                        matrix[x - 1, y - 1] = 1;//为了处理(1<<31)>>31这个特例
                    }
                }
                bitCompressedInt = int.Parse(xd1.GetElementsByTagName("e")[(y - 1) * 2 + 1].InnerText);
                for (int x = 33; x <= 64; x++)
                {
                    matrix[x - 1, y - 1] = (bitCompressedInt & (1 << (x - 33))) >> (x - 33);
                }
            } 
        }
        catch
        {

        }
    }
}
