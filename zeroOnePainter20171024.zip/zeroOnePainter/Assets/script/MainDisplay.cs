﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainDisplay : MonoBehaviour {
    float drawTime = 0f;
    float CD = 0f;
    int fps = 0;
    int previousFrames = 0;

    void Start()
    {

    }

    //仅计算fps
    void Update()
    {
        CD += Time.deltaTime;
        if (CD >= 1f)
        {
            fps = Time.frameCount - previousFrames;
            previousFrames = Time.frameCount;
            CD -= 1f;
        }
    }

    void OnGUI()
    {
        switch (GameStatus.currentSceneState)
        {
            case GameStatus.sceneState.help:
                GUI.DrawTexture(new Rect(0, 0, 960, 540), GameStatus.backTex);
                GUI.Label(new Rect(350, 20, 0, 0), "使 用 说 明", GameStatus.fontStyleTitle2);
                GUI.Label(new Rect(0, 20, 0, 0), "<< 返回", GameStatus.fontStyleTitle4);
                if(SystemInfo.operatingSystemFamily == OperatingSystemFamily.Windows)
                {
                    GUI.Label(new Rect(30, 100, 0, 0), "1.标题界面中，拖动滚动条改变颜色；\n" +
                        "2.右键单击屏幕可打开和关闭暂停设置界面；\n" + "3.游戏中有7种不同的0&1样式模板供选择；\n" +
                        "4.游戏有8个存档位，标题界面点击下方可选择。所有数据都是自动保存的；\n" + "5.因为没有多余的UI干扰，直接截屏即可分享作品；\n" +
                        "6.如果不小心把背景色和前景色弄得一样了，只要单击鼠标滚轮7次即可恢复颜色到默认值。\n"
                        , GameStatus.fontStyleSetting);
                }
                else
                {
                    GUI.Label(new Rect(30, 100, 0, 0), "1.标题界面中，拖动滚动条改变颜色；\n" +
                        "2.双指触屏可打开和关闭暂停设置界面；\n" + "3.游戏中有7种不同的0&1样式模板供选择；\n" +
                        "4.游戏有8个存档位，标题界面点击下方可选择。所有数据都是自动保存的；\n" + "5.因为没有多余的UI干扰，直接截屏即可分享作品；\n" +
                        "6.如果不小心把背景色和前景色弄得一样了，只要三根手指同时点击屏幕7次即可恢复颜色到默认值。\n"
                        , GameStatus.fontStyleSetting);
                }
                GUI.Label(new Rect(380, 280, 0, 0), "关 于 作 者", GameStatus.fontStyleTitle3);
                GUI.Label(new Rect(30, 340, 0, 0), "紫数。独立开发者。点击下方联系方式便可跳转到相应链接。可反馈和跟进新作消息。\n\n" +
                    "微博：@紫数purplemath\n\n" +
                    "TAPTAP主页：暗黑天鹅实验室\n\n" +
                    "官方QQ群：暗黑天鹅实验室（群号：511047526）\n\n"
                    , GameStatus.fontStyleSetting);
                break;
            case GameStatus.sceneState.title:
                
                GUI.DrawTexture(new Rect(0, 0, 960, 540), GameStatus.backTex);
                GUI.Label(new Rect(810, 0, 0, 0), "？", GameStatus.fontStyleTitle);
                GUI.Label(new Rect(886, 0, 0, 0), "X", GameStatus.fontStyleTitle);
                GUI.Label(new Rect(320, 0, 0, 0), "0 & 1画板", GameStatus.fontStyleTitle);

                #region 颜色选择
                GUI.Label(new Rect(80, 120, 0, 0), "背景颜色：\n\nR = " + Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.r * 255) +
                    "\n\nG = " + Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.g * 255) +
                    "\n\nB = " + Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.b * 255), GameStatus.fontStyleSetting);
                GUI.DrawTexture(new Rect(GameStatus.colorScrollBarStartX[0, 0],
                   GameStatus.colorScrollBarStartY[0, 0] + 13, 283, 2), GameStatus.scrollLineTex);
                GUI.DrawTexture(new Rect(GameStatus.colorScrollBarStartX[0, 0],
                   GameStatus.colorScrollBarStartY[0, 1] + 13, 283, 2), GameStatus.scrollLineTex);
                GUI.DrawTexture(new Rect(GameStatus.colorScrollBarStartX[0, 0],
                   GameStatus.colorScrollBarStartY[0, 2] + 13, 283, 2), GameStatus.scrollLineTex);
                GUI.DrawTexture(new Rect(GameStatus.colorScrollBarStartX[0, 0] +
                    Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.r * 255),
                    GameStatus.colorScrollBarStartY[0, 0], 28, 28), GameStatus.scrollBtnTex);
                GUI.DrawTexture(new Rect(GameStatus.colorScrollBarStartX[0, 0] +
                    Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.g * 255),
                    GameStatus.colorScrollBarStartY[0, 1], 28, 28), GameStatus.scrollBtnTex);
                GUI.DrawTexture(new Rect(GameStatus.colorScrollBarStartX[0, 0] +
                    Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.b * 255),
                    GameStatus.colorScrollBarStartY[0, 2], 28, 28), GameStatus.scrollBtnTex);
                GUI.Label(new Rect(488, 120, 0, 0), "字体颜色：\n\nR = " + Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.r * 255) +
                    "\n\nG = " + Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.g * 255) +
                    "\n\nB = " + Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.b * 255), GameStatus.fontStyleSetting);
                GUI.DrawTexture(new Rect(GameStatus.colorScrollBarStartX[0, 1],
                   GameStatus.colorScrollBarStartY[0, 0] + 13, 283, 2), GameStatus.scrollLineTex);
                GUI.DrawTexture(new Rect(GameStatus.colorScrollBarStartX[0, 1],
                   GameStatus.colorScrollBarStartY[0, 1] + 13, 283, 2), GameStatus.scrollLineTex);
                GUI.DrawTexture(new Rect(GameStatus.colorScrollBarStartX[0, 1],
                   GameStatus.colorScrollBarStartY[0, 2] + 13, 283, 2), GameStatus.scrollLineTex);
                GUI.DrawTexture(new Rect(GameStatus.colorScrollBarStartX[0, 1] +
                    Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.r * 255),
                    GameStatus.colorScrollBarStartY[0, 0], 28, 28), GameStatus.scrollBtnTex);
                GUI.DrawTexture(new Rect(GameStatus.colorScrollBarStartX[0, 1] +
                    Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.g * 255),
                    GameStatus.colorScrollBarStartY[0, 1], 28, 28), GameStatus.scrollBtnTex);
                GUI.DrawTexture(new Rect(GameStatus.colorScrollBarStartX[0, 1] +
                    Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.b * 255),
                    GameStatus.colorScrollBarStartY[0, 2], 28, 28), GameStatus.scrollBtnTex);

                #endregion

                GUI.Label(new Rect(410, 350, 0, 0), ">> 继续画画！", GameStatus.fontStyleBtn);

                //GUI.DrawTexture(new Rect(285, 195, 28, 28), GameStatus.scrollBtn);
                #region 显示画布档位
                for(int i = 1; i <= 8; i++)
                {
                    GUI.DrawTexture(new Rect((i - 1) * 120, 450, 120, 90), GameStatus.slotFrameTex);
                    if (i == GameStatus.currentSlot)
                    {
                        GUI.DrawTexture(new Rect((i - 1) * 120 - 2, 425, 120, 25), GameStatus.slotLabelTex);
                        GUI.Label(new Rect((i - 1) * 120 + 12, 426, 0, 0), "当前画布", GameStatus.fontStyleMenu);
                    }
                }
                GUI.Label(new Rect(44, 470, 0, 0), "1       " + "2       " + "3       " + "4       "
                    + " 5       " + "6       " + "7       " + "8       ", GameStatus.fontStyleTitle2);

                #endregion
                break;
            case GameStatus.sceneState.drawing:
                GUI.DrawTexture(new Rect(0, 0, 960, 540), GameStatus.backTex);
                GUI.DrawTexture(new Rect(0, 0, 960, 540), GameStatus.frontTex);
                break;
            case GameStatus.sceneState.pause:
                GUI.DrawTexture(new Rect(0, 0, 960, 540), GameStatus.backTex);
                GUI.DrawTexture(new Rect(0, 0, 960, 540), GameStatus.frontTex);
                GUI.DrawTexture(new Rect(160, 90, 640, 360), GameStatus.menuTex);
                if(SystemInfo.operatingSystemFamily == OperatingSystemFamily.Windows)
                {
                    GUI.Label(new Rect(300, 100, 0, 0), "（单击右键打开或关闭此面板……）", GameStatus.fontStyleMenu);
                }
                else
                {
                    GUI.Label(new Rect(300, 100, 0, 0), "（双指触屏打开或关闭此面板……）", GameStatus.fontStyleMenu);
                }
                GUI.Label(new Rect(200, 160, 0, 0), "笔刷类型", GameStatus.fontStyleMenu);
                if (GameStatus.isPaintingOne)
                {
                    GUI.DrawTexture(new Rect(365, 142, 60, 60), GameStatus.brushTypeChoosedArrowTex);
                }
                else
                {
                    GUI.DrawTexture(new Rect(305, 142, 60, 60), GameStatus.brushTypeChoosedArrowTex);
                }
                GUI.DrawTexture(new Rect(317, 154, 36, 36), GameStatus.brushTypeBackTex);
                GUI.DrawTexture(new Rect(377, 154, 36, 36), GameStatus.brushTypeBackTex);
                GUI.DrawTexture(new Rect(320, 157, 30, 30), Template01Bank.templateList[SlotBank.slotArray[GameStatus.currentSlot - 1].templateId - 1].textures[0]);
                GUI.DrawTexture(new Rect(380, 157, 30, 30), Template01Bank.templateList[SlotBank.slotArray[GameStatus.currentSlot - 1].templateId - 1].textures[1]);

                GUI.Label(new Rect(465, 160, 0, 0), "笔刷直径：1       3       5", GameStatus.fontStyleMenu);
                GUI.DrawTexture(new Rect(605, 160, 26, 26), GameStatus.circleBackTex);
                GUI.DrawTexture(new Rect(667, 160, 26, 26), GameStatus.circleBackTex);
                GUI.DrawTexture(new Rect(729, 160, 26, 26), GameStatus.circleBackTex);
                GUI.DrawTexture(new Rect(613 + (GameStatus.brushSize - 1) * 31, 168, 9, 9), GameStatus.circleFrontTex);
                if(SlotBank.slotArray[GameStatus.currentSlot - 1].undoList.Count > 1)//第一个撤销档是保底的，不能被调用
                {
                    GUI.Label(new Rect(200, 230, 0, 0), ">> 撤销一笔" + "           >> 全部置零           >> 全部置一\n\n" +
                        ">> 帮助说明           >> 返回标题", GameStatus.fontStyleMenu);
                    GUI.Label(new Rect(340, 230, 0, 0), "(" + (SlotBank.slotArray[GameStatus.currentSlot - 1].undoList.Count-1) + ")",
                        GameStatus.fontStyleMenu);
                }
                else
                {
                    GUI.Label(new Rect(200, 230, 0, 0), "--无法撤销--" + "           >> 全部置零           >> 全部置一\n\n" +
                        ">> 帮助说明           >> 返回标题", GameStatus.fontStyleMenu);
                }
                /*GUI.Label(new Rect(200, 230, 0, 0), ((SlotBank.slotArray[GameStatus.currentSlot -1].undoList.Count>=1)?">> 撤销一笔" : "--无法撤销--")
                    +"           >> 全部置零           >> 全部置一\n\n"+
                    ">> 帮助说明           >> 返回标题", GameStatus.fontStyleMenu);*/
                for(int i = 1; i <= 6; i++)
                {
                    GUI.DrawTexture(new Rect(160 + i * 80, 370, 80, 60), GameStatus.templateFrameTex);
                    if (i == SlotBank.slotArray[GameStatus.currentSlot - 1].templateId)
                    {
                        GUI.DrawTexture(new Rect(160 + i * 80, 350, 80, 20), GameStatus.templateLabelTex);
                        GUI.Label(new Rect(160 + i * 80, 350, 0, 0), "当前模板", GameStatus.fontStyleVersion);
                    }
                }
                GUI.Label(new Rect(270, 385, 0, 0), "1          2          3         4          5          6", GameStatus.fontStyleMenu);

                break;
            default:
                break;
        }
        if (GameStatus.isShowingFPS)
        {
            GUI.Label(new Rect(0, 0, 0, 0), "fps=" + fps, GameStatus.fontStyleSystem);
        }
        displayTextBullet();
    }

    void displayTextBullet()
    {
        
        if (GameStatus.textBulletList.Count > 0)
        {
            if (SlotBank.slotArray[GameStatus.currentSlot-1].BackColorBrightness <= 1)
            {
                GameStatus.fontStyleSystem.normal.textColor = new Color(0.9f + Mathf.Cos(Time.time * 32f + 1.56f) * 0.1f,
                    0.9f + Mathf.Cos(Time.time * 32f + 2.34f) * 0.1f, 0.9f + Mathf.Cos(Time.time * 32f) * 0.1f, 0.9f);
            }
            else
            {
                GameStatus.fontStyleSystem.normal.textColor = new Color(0f + Mathf.Cos(Time.time * 32f + 1.56f) * 0.1f,
                    0f + Mathf.Cos(Time.time * 32f + 2.34f) * 0.1f, 0f + Mathf.Cos(Time.time * 32f) * 0.1f, 0.6f);
            }
            for (int i = GameStatus.textBulletList.Count; i >= 1; i--)
            {
                GUI.Label(GameStatus.textBulletList[i - 1].position, GameStatus.textBulletList[i - 1].text, GameStatus.fontStyleSystem);
                GameStatus.textBulletList[i - 1].position.x -= GameStatus.textBulletList[i - 1].speed * Time.deltaTime;
                if (GameStatus.textBulletList[i - 1].position.x + GameStatus.textBulletList[i - 1].text.Length * 24 <= 0)
                {
                    GameStatus.textBulletList.RemoveAt(i - 1);
                }
            }
        }
    }

}
