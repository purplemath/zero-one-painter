﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Template01 {
    public int[,,] matrixs = new int[2, 15, 15];
    public Texture2D[] textures = new Texture2D[2];

    public Template01()
    {
        for(int i = 1; i <= 2; i++)
        {
            for(int x = 1; x <= 15; x++)
            {
                for(int y = 1; y <= 15; y++)
                {
                    matrixs[i - 1, x - 1, y - 1] = 0;
                }
            }
        }
        textures[0] = new Texture2D(15, 15);
        textures[1] = new Texture2D(15, 15);
    }
}
