﻿using System.Collections;
using System.Collections.Generic;
using System.Xml;
using UnityEngine;

public class GameStatus{
    public enum sceneState
    {
        title, drawing, help, pause
    }
    public static sceneState currentSceneState = sceneState.title;
    public static sceneState previousSceneState = sceneState.title;
    public static int currentSlot = 5;
    public static bool isShowingFPS = false;
    public static List<TextBullet> textBulletList = new List<TextBullet>();
    public static int currentTextBulletUid = 1;
    public static int textBulletSize = 24;
    public static bool isDoubleTouched = false;
    public static bool isTrueSingleTouch = false;
    public static int changingColorId = 0;
    public static int changingColorPositionXFix = 0;
    public static int resetColorCode = 0;
    public static bool closeColorWarningOn = false;
    public static float closeColorWarningCD = 0f;
    public static bool closeColorWarningHasShowHint = false;
    public const int maxUndoCount = 10;
    public static int currentReadingSlotId = 1;

    #region 坐标偏移
    public static int[,] colorScrollBarStartX = new int[2, 2];
    public static int[,] colorScrollBarStartY = new int[2, 3];
    #endregion

    #region 显示相关
    public static Texture2D frontTex = new Texture2D(960, 540);
    public static Texture2D menuTex = new Texture2D(1, 1);
    public static Texture2D backTex = new Texture2D(1, 1);
    public static Texture2D scrollBtnTex = new Texture2D(7, 7);
    public static Texture2D scrollLineTex = new Texture2D(1, 1);
    public static Texture2D slotFrameTex = new Texture2D(40, 30);
    public static Texture2D slotLabelTex = new Texture2D(1, 1);
    public static Texture2D circleFrontTex = new Texture2D(13, 13);
    public static Texture2D circleBackTex = new Texture2D(13, 13);
    public static Texture2D brushTypeChoosedArrowTex = new Texture2D(31, 31);
    public static Texture2D brushTypeBackTex = new Texture2D(1, 1);
    public static Texture2D templateFrameTex = new Texture2D(40, 30);
    public static Texture2D templateLabelTex = new Texture2D(1, 1);

    #region 图像模板
    public static int[,] scrollBtnMatrix = new int[7, 7];
    public static int[,] scrollLineMatrix = new int[1, 1];
    public static int[,] slotFrameMatrix = new int[40, 30];
    #endregion
    #region 字体相关
    public static GUIStyle fontStyleTitle = new GUIStyle();
    public static GUIStyle fontStyleTitle2 = new GUIStyle();
    public static GUIStyle fontStyleTitle3 = new GUIStyle();
    public static GUIStyle fontStyleTitle4 = new GUIStyle();
    public static GUIStyle fontStyleVersion = new GUIStyle();
    public static GUIStyle fontStyleSetting = new GUIStyle();
    public static GUIStyle fontStyleBtn = new GUIStyle();
    public static GUIStyle fontStyleSystem = new GUIStyle();
    public static GUIStyle fontStyleMenu = new GUIStyle();
    #endregion
    #endregion

    #region 绘图设置和状态
    public static bool isPaintingOne = true;
    public static int brushSize = 1;
    public static float forceDrawPointCD = 0f;

    /*public static int[] backColorSliderInt = { 0, 0, 0 };
    public static int[] frontColorSliderInt = { 0, 0, 0 };*/
    public static float previousTime = 0f;
    public static float currentTime = 0f;
    public static Vector3 previousPosition = new Vector3(0, 0, 0);
    public static Vector3 currentPosition = new Vector3(0, 0, 0);
    public static Vector3 startPoint = new Vector3(0, 0, 0);
    public static Vector3 endPoint = new Vector3(0, 0, 0);
    #endregion

    #region 变量相关类
    public static void initNumbers()
    {
        for(int i = 1; i <= 2; i++)
        {
            colorScrollBarStartX[i - 1, 0] = 180;
            colorScrollBarStartX[i - 1, 1] = 588;
            colorScrollBarStartY[i - 1, 0] = 165;
            colorScrollBarStartY[i - 1, 1] = 213;
            colorScrollBarStartY[i - 1, 2] = 261;
        }
    }
    #endregion

    #region 刷新显示类
    public static void initDisplayStuffs()
    {
        Screen.SetResolution(960, 540, true);

        initBitmapMatrix();
        generateFrontTex();
        generateBackTex();
        initGUIStyle();
    }

    public static void initBitmapMatrix()
    {
        #region 按钮
        for(int i = 1; i <= 7; i++)
        {
            for(int j = 1; j <= 7; j++)
            {
                scrollBtnMatrix[i - 1, j - 1] = 1;
            }
        }
        for(int i = 1; i <= 5; i++)
        {
            scrollBtnMatrix[i, 1] = 0;
            scrollBtnMatrix[i, 5] = 0;
        }
        for (int j = 1; j <= 5; j++)
        {
            scrollBtnMatrix[1, j] = 0;
            scrollBtnMatrix[5, j] = 0;
        }
        #endregion
        #region 线
        scrollLineMatrix[0, 0] = 1;
        #endregion
        #region 画布档位边框
        for(int x = 1; x <= 40; x++)
        {
            for(int y = 1; y <= 30; y++)
            {
                slotFrameMatrix[x - 1, y - 1] = 0;
            }
        }
        for(int x = 1; x <= 40; x++)
        {
            slotFrameMatrix[x - 1, 29] = 1;
        }
        for (int y = 1; y <= 30; y++)
        {
            slotFrameMatrix[39, y - 1] = 1;
        }
        #endregion

    }

    public static void initGUIStyle()
    {
        fontStyleTitle.normal.background = null;
        fontStyleTitle.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
        fontStyleTitle.fontSize = 72;
        fontStyleTitle2.normal.background = null;
        fontStyleTitle2.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
        fontStyleTitle2.fontSize = 48;
        fontStyleTitle3.normal.background = null;
        fontStyleTitle3.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
        fontStyleTitle3.fontSize = 36;
        fontStyleTitle4.normal.background = null;
        fontStyleTitle4.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
        fontStyleTitle4.fontSize = 32;
        fontStyleVersion.normal.background = null;
        fontStyleVersion.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
        fontStyleVersion.fontSize = 18;
        fontStyleSetting.normal.background = null;
        fontStyleSetting.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
        fontStyleSetting.fontSize = 21;
        fontStyleBtn.normal.background = null;
        fontStyleBtn.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
        fontStyleBtn.fontSize = 24;
        fontStyleSystem.normal.background = null;
        fontStyleSystem.normal.textColor = Color.black;
        fontStyleSystem.fontSize = 24;
        fontStyleMenu.normal.background = null;
        fontStyleMenu.normal.textColor = SlotBank.slotArray[currentSlot - 1].backColor;
        fontStyleMenu.fontSize = 24;
    }

    public static void generateBackTex()//这个不能放在摄像机上，摄像机和实际舞台之间有10f的距离。
    {
        refreshFontBackColor();
        backTex.SetPixel(0, 0, SlotBank.slotArray[currentSlot - 1].backColor);
        backTex.Apply();

        #region 背景色圆
        for (int x = 1; x <= 13; x++)
        {
            for (int y = 1; y <= 13; y++)
            {
                if (Mathf.Sqrt((x - 7f) * (x - 7f) + (y - 7f) * (y - 7f)) <= 7f)
                {
                    circleBackTex.SetPixel(x - 1, y - 1, SlotBank.slotArray[currentSlot - 1].backColor);
                }
                else
                {
                    circleBackTex.SetPixel(x - 1, y - 1, new Color(0,0,0,0));
                }
            }
        }
        circleBackTex.Apply();
        #endregion
    }

    public static void generateFrontTex(bool isInDrawing = true)
    {
        refreshFontFrontColor();

        if (isInDrawing)
        {

            menuTex.SetPixel(0, 0, SlotBank.slotArray[currentSlot - 1].frontColor);
            menuTex.Apply();

            #region 01模板绘制。必须在frontTex绘制之前，否则颜色来不及更新
            for (int i = 0; i <= 1; i++)
            {
                for (int x = 1; x <= 15; x++)
                {
                    for (int y = 1; y <= 15; y++)
                    {
                        if (Template01Bank.templateList[SlotBank.slotArray[currentSlot - 1].templateId - 1].matrixs[i, x - 1, y - 1] == 1)
                        {
                            Template01Bank.templateList[SlotBank.slotArray[currentSlot - 1].templateId - 1].textures[i].SetPixel(x - 1, y - 1,
                                SlotBank.slotArray[currentSlot - 1].frontColor);
                        }
                        else
                        {
                            Template01Bank.templateList[SlotBank.slotArray[currentSlot - 1].templateId - 1].textures[i].SetPixel(x - 1, y - 1,
                                SlotBank.slotArray[currentSlot - 1].backColor);
                        }
                    }
                }
                Template01Bank.templateList[SlotBank.slotArray[currentSlot - 1].templateId - 1].textures[i].Apply();
            }
            #endregion
            #region frontTex整体绘制
            for (int i = 1; i <= 64; i++)
            {
                for (int j = 1; j <= 36; j++)
                {
                    #region 旧绘制方式
                    /*for (int y = 1; y <= 5; y++)
                    {
                        for (int x = 1; x <= 5; x++)
                        {
                            frontTex.SetPixel((i - 1) * 5 + x - 1, (j - 1) * 5 + y - 1, new Color(0, 0, 0, 0));
                        }
                    }
                    if (SlotBank.slotArray[GameStatus.currentSlot - 1].matrix[i - 1, j - 1] == 1)
                    {
                        for (int y = 1; y <= 5; y++)
                        {
                            frontTex.SetPixel((i - 1) * 5 + 2, (j - 1) * 5 + y - 1, SlotBank.slotArray[currentSlot - 1].frontColor);
                        }
                    }
                    else
                    {
                        for (int y = 1; y <= 5; y++)
                        {
                            frontTex.SetPixel((i - 1) * 5 + 1, (j - 1) * 5 + y - 1, SlotBank.slotArray[currentSlot - 1].frontColor);
                            frontTex.SetPixel((i - 1) * 5 + 3, (j - 1) * 5 + y - 1, SlotBank.slotArray[currentSlot - 1].frontColor);
                        }
                        for (int x = 2; x <= 4; x++)
                        {
                            frontTex.SetPixel((i - 1) * 5 + x - 1, (j - 1) * 5, SlotBank.slotArray[currentSlot - 1].frontColor);
                            frontTex.SetPixel((i - 1) * 5 + x - 1, (j - 1) * 5 + 4, SlotBank.slotArray[currentSlot - 1].frontColor);
                        }
                    }*/
                    #endregion
                    for (int x = 1; x <= 15; x++)
                    {
                        for(int y = 1; y <= 15; y++)
                        {
                            try
                            {
                                frontTex.SetPixel((i - 1) * 15 + x - 1, (j - 1) * 15 + y - 1,
                                    Template01Bank.templateList[SlotBank.slotArray[currentSlot - 1].templateId - 1].
                                    textures[SlotBank.slotArray[currentSlot - 1].matrix[i - 1, j - 1]].GetPixel(x - 1, y - 1));
                            }
                            catch
                            {
                                Debug.Log("(" + x + "," + y + ")");
                                Debug.Log(SlotBank.slotArray[currentSlot - 1].matrix[i - 1, j - 1]);
                                return;
                            }
                            /*frontTex.SetPixel((i - 1) * 15 + x - 1, (j - 1) * 15 + y - 1,
                                Template01Bank.templateList[SlotBank.slotArray[currentSlot - 1].templateId - 1].
                                textures[0].GetPixel(x - 1, y - 1));*/
                        }
                    }
                }
            }
            frontTex.Apply();
            #endregion

            #region 笔刷选择框
            brushTypeBackTex.SetPixel(0, 0, SlotBank.slotArray[currentSlot - 1].backColor);
            brushTypeBackTex.Apply();

            for (int x = 1; x <= 31; x++)
            {
                for (int y = 1; y <= 31; y++)
                {
                    if (Mathf.Abs(Mathf.Sqrt((x - 16f) * (x - 16f) + (y - 16f) * (y - 16f)) - 15f) < 0.5f)
                    {
                        brushTypeChoosedArrowTex.SetPixel(x - 1, y - 1, SlotBank.slotArray[currentSlot - 1].backColor);
                    }
                    else
                    {
                        brushTypeChoosedArrowTex.SetPixel(x - 1, y - 1, SlotBank.slotArray[currentSlot - 1].frontColor);
                    }
                }
            }
            brushTypeChoosedArrowTex.Apply();
            #endregion
            #region 其它框绘制
            for(int x = 1; x <= 40; x++)
            {
                for(int y = 1; y <= 30; y++)
                {
                    templateFrameTex.SetPixel(x - 1, y - 1, SlotBank.slotArray[currentSlot - 1].frontColor);
                }
            }
            for(int x = 1; x <= 40; x++)
            {
                templateFrameTex.SetPixel(x - 1, 0, SlotBank.slotArray[currentSlot - 1].backColor);
                templateFrameTex.SetPixel(x - 1, 29, SlotBank.slotArray[currentSlot - 1].backColor);
            }
            for(int y = 1; y <= 30; y++)
            {
                templateFrameTex.SetPixel(0, y - 1, SlotBank.slotArray[currentSlot - 1].backColor);
                templateFrameTex.SetPixel(39, y - 1, SlotBank.slotArray[currentSlot - 1].backColor);
            }
            templateFrameTex.Apply();
            templateLabelTex.SetPixel(0, 0, SlotBank.slotArray[currentSlot - 1].backColor);
            templateLabelTex.Apply();
            #endregion
        }

        #region 滚动条相关绘制
        for (int x = 1; x <= 7; x++)
        {
            for(int y = 1; y <= 7; y++)
            {
                if (scrollBtnMatrix[x - 1, y - 1] == 1)
                {
                    scrollBtnTex.SetPixel(x - 1, y - 1, SlotBank.slotArray[currentSlot - 1].frontColor);
                }
                else
                {
                    scrollBtnTex.SetPixel(x - 1, y - 1, SlotBank.slotArray[currentSlot - 1].backColor);
                }
            }
        }
        scrollBtnTex.Apply();
        scrollLineTex.SetPixel(0, 0, SlotBank.slotArray[currentSlot - 1].frontColor);
        scrollLineTex.Apply();
        #endregion
        #region 画布档位相关绘制
        for(int x = 1; x <= 40; x++)
        {
            for(int y = 1; y <= 30; y++)
            {
                if (slotFrameMatrix[x - 1, y - 1] == 1)
                {
                    slotFrameTex.SetPixel(x - 1, y - 1, SlotBank.slotArray[currentSlot - 1].frontColor);
                }
                else
                {
                    slotFrameTex.SetPixel(x - 1, y - 1, SlotBank.slotArray[currentSlot - 1].backColor);
                }
            }
        }
        slotFrameTex.Apply();
        slotLabelTex.SetPixel(0, 0, SlotBank.slotArray[currentSlot - 1].frontColor);
        slotLabelTex.Apply();
        #endregion

        #region 前景色圆
        for (int x = 1; x <= 13; x++)
        {
            for (int y = 1; y <= 13; y++)
            {
                if (Mathf.Sqrt((x - 7f) * (x - 7f) + (y - 7f) * (y - 7f)) <= 7f)
                {
                    circleFrontTex.SetPixel(x - 1, y - 1, SlotBank.slotArray[currentSlot - 1].frontColor);
                }
                else
                {
                    circleFrontTex.SetPixel(x - 1, y - 1, new Color(0, 0, 0, 0));
                }
            }
        }
        circleFrontTex.Apply();
        #endregion
    }

    public static void refreshFontBackColor()
    {
        fontStyleMenu.normal.textColor = SlotBank.slotArray[currentSlot - 1].backColor;
    }

    public static void refreshFontFrontColor()
    {
        fontStyleTitle.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
        fontStyleTitle2.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
        fontStyleTitle3.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
        fontStyleTitle4.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
        fontStyleVersion.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
        fontStyleSetting.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
        fontStyleBtn.normal.textColor = SlotBank.slotArray[currentSlot - 1].frontColor;
    }

    /// <summary>
    /// 获取弹幕位置Rect
    /// </summary>
    /// <param name="strlength"></param>
    /// <returns></returns>
    public static Rect getBulletTextRect(int strlength)
    {
        if (textBulletList.Count == 0)
        {
            currentTextBulletUid = 1;
            return new Rect(960 + 40 * textBulletList.Count + Mathf.FloorToInt(textBulletList.Count / 20) * 800,
                    0, strlength * textBulletSize, textBulletSize);
        }
        else
        {
            return new Rect(960 + 40 * textBulletList.Count + Mathf.FloorToInt(textBulletList.Count / 20) * 800,
                    27 * (textBulletList[textBulletList.Count - 1].uid % 20), strlength * textBulletSize, textBulletSize);
        }
    }
    #endregion

    #region 画板逻辑状态类
    /// <summary>
    /// 重置画板
    /// </summary>
    /// <param name="n"></param>
    public static void resetMatrix(int n = 0)
    {
        for (int i = 1; i <= 64; i++)
        {
            for (int j = 1; j <= 36; j++)
            {
                SlotBank.slotArray[GameStatus.currentSlot - 1].matrix[i - 1, j - 1] = n;
            }
        }
    }

    /// <summary>
    /// 画线
    /// </summary>
    /// <param name="startPoint"></param>
    /// <param name="endPoint"></param>
    public static void drawLine(Vector3 startPoint,Vector3 endPoint)
    {
        float distance = Vector3.Distance(startPoint, endPoint);
        if (distance < 0.1f)
        {
            forceDrawPointCD -= Time.deltaTime;
            if (forceDrawPointCD <= 0f)
            {
                forceDrawPointCD = 1f;
            }
            else
            {
                return;
            }
        }
        int steps = Mathf.CeilToInt(distance / 15f);
        for (int i = 0; i <= steps; i++)
        {
            int col = Mathf.Max(1, Mathf.Min(64, Mathf.CeilToInt((startPoint.x + (endPoint.x - startPoint.x) / Mathf.Max(1, steps) * i) / 15f)));
            int row = Mathf.Max(1, Mathf.Min(36, Mathf.CeilToInt((startPoint.y + (endPoint.y - startPoint.y) / Mathf.Max(1, steps) * i) / 15f)));
            drawPoint(col, row);
            if(brushSize > 2)
            {
                drawPoint(Mathf.Max(1, col - 1), row);
                drawPoint(Mathf.Min(64, col + 1), row);
                drawPoint(col, Mathf.Max(1, row - 1));
                drawPoint(col, Mathf.Min(36, row + 1));
            }
            if(brushSize > 4)
            {
                drawPoint(Mathf.Max(1, col - 1), Mathf.Max(1, row - 1));
                drawPoint(Mathf.Max(1, col - 1), Mathf.Min(36, row + 1));
                drawPoint(Mathf.Min(64, col + 1), Mathf.Max(1, row - 1));
                drawPoint(Mathf.Min(64, col + 1), Mathf.Min(36, row + 1));

                drawPoint(Mathf.Max(1, col - 2), row);
                drawPoint(Mathf.Min(64, col + 2), row);
                drawPoint(col, Mathf.Max(1, row - 2));
                drawPoint(col, Mathf.Min(36, row + 2));
            }
        }
        frontTex.Apply();
    }
    
    /// <summary>
    /// 画点
    /// </summary>
    /// <param name="col"></param>
    /// <param name="row"></param>
    public static void drawPoint(int col,int row)
    {
        #region 旧绘制方式
        /*for (int y = 1; y <= 5; y++)
        {
            for (int x = 1; x <= 5; x++)
            {
                frontTex.SetPixel((col - 1) * 5 + x - 1, (row - 1) * 5 + y - 1, new Color(0, 0, 0, 0));
            }
        }
        if (isPaintingOne)
        {
            SlotBank.slotArray[currentSlot - 1].matrix[col - 1, row - 1] = 1;
            for (int y = 1; y <= 5; y++)
            {
                frontTex.SetPixel((col - 1) * 5 + 2, (row - 1) * 5 + y - 1, SlotBank.slotArray[currentSlot - 1].frontColor);
            }
        }
        else
        {
            SlotBank.slotArray[currentSlot - 1].matrix[col - 1, row - 1] = 0;
            for (int y = 1; y <= 5; y++)
            {
                frontTex.SetPixel((col - 1) * 5 + 1, (row - 1) * 5 + y - 1, SlotBank.slotArray[currentSlot - 1].frontColor);
                frontTex.SetPixel((col - 1) * 5 + 3, (row - 1) * 5 + y - 1, SlotBank.slotArray[currentSlot - 1].frontColor);
            }
            for (int x = 2; x <= 4; x++)
            {
                frontTex.SetPixel((col - 1) * 5 + x - 1, (row - 1) * 5, SlotBank.slotArray[currentSlot - 1].frontColor);
                frontTex.SetPixel((col - 1) * 5 + x - 1, (row - 1) * 5 + 4, SlotBank.slotArray[currentSlot - 1].frontColor);
            }
        }*/
        #endregion
        if (isPaintingOne)
        {
            SlotBank.slotArray[currentSlot - 1].matrix[col - 1, row - 1] = 1;
            for (int x = 1; x <= 15; x++)
            {
                for (int y = 1; y <= 15; y++)
                {
                    frontTex.SetPixel((col - 1) * 15 + x - 1, (row - 1) * 15 + y - 1,
                        Template01Bank.templateList[SlotBank.slotArray[currentSlot - 1].templateId - 1].textures[1].GetPixel(x - 1, y - 1));
                }
            }
        }
        else
        {
            SlotBank.slotArray[currentSlot - 1].matrix[col - 1, row - 1] = 0;
            for (int x = 1; x <= 15; x++)
            {
                for (int y = 1; y <= 15; y++)
                {
                    frontTex.SetPixel((col - 1) * 15 + x - 1, (row - 1) * 15 + y - 1,
                        Template01Bank.templateList[SlotBank.slotArray[currentSlot - 1].templateId - 1].textures[0].GetPixel(x - 1, y - 1));
                }
            }
        }
    }

    #endregion

    #region 保存类
    /// <summary>
    /// 保存进度。保存条件为：颜色变更、模板变更、每画完一笔、每撤销一步、每重置一次、每次恢复配色
    /// </summary>
    public static void saveGame()
    {
        PlayerPrefs.SetString("_slotData" + currentSlot.ToString(), SlotBank.slotArray[currentSlot - 1].SlotXml);
        PlayerPrefs.SetInt("_previousSlot", currentSlot);
    }

    public static void loadGame()
    {
        if (PlayerPrefs.HasKey("_previousSlot"))
        {
            try
            {
                currentSlot = PlayerPrefs.GetInt("_previousSlot");
            }
            catch
            {
                currentSlot = 5;
            }
        }
        for (int i = 1; i <= 8; i++)
        {
            if (PlayerPrefs.HasKey("_slotData" + i))
            {
                try
                {
                    currentReadingSlotId = i;
                    SlotBank.slotArray[i - 1].loadFromXml(PlayerPrefs.GetString("_slotData" + i));
                }
                catch
                {
                    textBulletList.Add(new TextBullet("读取档位" + i + "时发生了错误", getBulletTextRect(11), Color.black));
                    Debug.Log("读取档位" + i + "时发生了错误");
                }
            }
        }
    }
    #endregion

}
