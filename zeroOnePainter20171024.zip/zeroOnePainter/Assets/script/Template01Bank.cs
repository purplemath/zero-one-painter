﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Template01Bank : MonoBehaviour {
    public static Template01[] templateList = new Template01[6];

    public static void initTemplates()
    {
        #region 注释
        //软01、硬01、空和全、软○和×、硬○和×、○和一
        #endregion
        for(int i = 1; i <= 6; i++)
        {
            templateList[i - 1] = new Template01();
        }

        #region #1
        for(int x = 6; x <= 8; x++)
        {
            templateList[0].matrixs[0, x, 2] = 1;
            templateList[0].matrixs[0, x, 12] = 1;
        }
        templateList[0].matrixs[0, 5, 3] = 1;
        templateList[0].matrixs[0, 5, 11] = 1;
        templateList[0].matrixs[0, 9, 3] = 1;
        templateList[0].matrixs[0, 9, 11] = 1;
        for(int y = 4; y <= 10; y++)
        {
            templateList[0].matrixs[0, 4, y] = 1;
            templateList[0].matrixs[0, 10, y] = 1;
        }
        for(int y = 3; y <= 12; y++)
        {
            templateList[0].matrixs[1, 7, y] = 1;
        }
        for(int x = 5; x <= 9; x++)
        {
            templateList[0].matrixs[1, x, 2] = 1;
        }
        templateList[0].matrixs[1, 6, 11] = 1;
        templateList[0].matrixs[1, 5, 10] = 1;
        #endregion

        #region #2
        for (int y = 1; y <= 13; y++)
        {
            for (int x = 3; x <= 5; x++)
            {
                templateList[1].matrixs[0, x, y] = 1;
            }
            for (int x = 9; x <= 11; x++)
            {
                templateList[1].matrixs[0, x, y] = 1;
            }
        }
        for (int x = 6; x <= 8; x++)
        {
            for (int y = 1; y <= 3; y++)
            {
                templateList[1].matrixs[0, x, y] = 1;
            }
            for (int y = 11; y <= 13; y++)
            {
                templateList[1].matrixs[0, x, y] = 1;
            }
        }
        for(int x = 6; x <= 8; x++)
        {
            for(int y = 1; y <= 13; y++)
            {
                templateList[1].matrixs[1, x, y] = 1;
            }
        }
        #endregion

        #region #3
        for (int x = 0; x <= 14; x++)
        {
            for (int y = 0; y <= 14; y++)
            {
                templateList[2].matrixs[1, x, y] = 1;
            }
        }
        #endregion

        #region #4
        for(int x = 2; x <= 14; x++)
        {
            for(int y = 2; y <= 14; y++)
            {
                if (Mathf.Abs(Mathf.Sqrt((x - 8f) * (x - 8f) + (y - 8f) * (y - 8f)) - 6f) < 0.5f)
                {
                    templateList[3].matrixs[0, x - 1, y - 1] = 1;
                }
            }
        }
        for(int i = 3; i <= 13; i++)
        {
            templateList[3].matrixs[1, i - 1, i - 1] = 1;
            templateList[3].matrixs[1, i - 1, 15 - i] = 1;
        }
        #endregion

        #region #5

        for (int x = 1; x <= 15; x++)
        {
            for (int y = 1; y <= 15; y++)
            {
                if (Mathf.Sqrt((x - 8f) * (x - 8f) + (y - 8f) * (y - 8f)) <= 7.3f)
                {
                    templateList[4].matrixs[0, x - 1, y - 1] = 1;
                }
            }
        }
        for (int i = 1; i <= 15; i++)
        {
            templateList[4].matrixs[1, i - 1, i - 1] = 1;
            templateList[4].matrixs[1, i - 1, 15 - i] = 1;
        }
        for (int i = 2; i <= 15; i++)
        {
            templateList[4].matrixs[1, i - 1, i - 2] = 1;
            templateList[4].matrixs[1, i - 1, 16 - i] = 1;
        }
        for (int i = 1; i <= 14; i++)
        {
            templateList[4].matrixs[1, i - 1, i] = 1;
            templateList[4].matrixs[1, i - 1, 14 - i] = 1;
        }
        #endregion

        #region #6
        for (int x = 1; x <= 15; x++)
        {
            for (int y = 1; y <= 15; y++)
            {
                if (Mathf.Abs(Mathf.Sqrt((x - 8f) * (x - 8f) + (y - 8f) * (y - 8f)) - 6f) < 0.5f)
                {
                    templateList[5].matrixs[0, x - 1, y - 1] = 1;
                }
            }
        }
        for(int x = 3; x <= 13; x++)
        {
            templateList[5].matrixs[1, x - 1, 7] = 1;
        }
        #endregion
    }
}
