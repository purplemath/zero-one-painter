﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainLogic : MonoBehaviour {
    // Use this for initialization
    void Start ()
    {
        #region test
        /*int a = 0;
        a |= 1 << 2;
        a |= 1 << 3;
        a |= 0 << 4;
        print(a);*/
        /*int bitCompressedInt = 127;
        for (int x = 1; x <= 32; x++)
        {
            print(bitCompressedInt & (1 << (x - 1)));
        }*/
        //print((1 << 31) >> 31);
        #endregion
        try
        {

            SlotBank.initSlotBank();
            Template01Bank.initTemplates();
            GameStatus.loadGame();
            for (int i = 1; i <= 8; i++)
            {
                SlotBank.slotArray[i - 1].saveMatrix();//第一个撤销档是保底的，不能被undo
                                                       //之所以放在这里而不是放在loadxml方法里是为了考虑到没有存档的新画布
            }
            GameStatus.initNumbers();
        }
        catch
        {
            GameStatus.textBulletList.Add(new TextBullet("error happened in logic", GameStatus.getBulletTextRect(15), Color.black));
        }
        try
        {
            GameStatus.initDisplayStuffs();
        }
        catch
        {
            GameStatus.textBulletList.Add(new TextBullet("error happened in display", GameStatus.getBulletTextRect(15), Color.black));
        }
    }

    void Update()
    {
        closeColorWarningCircle();
        #region 清空操作。三重触屏7次还原颜色配置
        if (Input.GetMouseButtonUp(2))
        {
            if (GameStatus.resetColorCode == 6)
            {
                GameStatus.resetColorCode = 0;
                SlotBank.resetColor(GameStatus.currentSlot);
                GameStatus.textBulletList.Clear();
                GameStatus.saveGame();
                GameStatus.generateFrontTex();
                GameStatus.generateBackTex();
                GameStatus.closeColorWarningOn = false;
            }
            else
            {
                GameStatus.resetColorCode += 1;
            }
        }
        #endregion
        switch (GameStatus.currentSceneState)
        {
            case GameStatus.sceneState.help:
                #region 帮助界面
                if (Input.GetMouseButtonUp(0))
                {
                    //print(Input.mousePosition);
                    if (Input.mousePosition.y >= 480 && Input.mousePosition.y <= 530 && Input.mousePosition.x <= 128)
                    {
                        //print("return");
                        if(GameStatus.previousSceneState == GameStatus.sceneState.title)
                        {
                            GameStatus.currentSceneState = GameStatus.sceneState.title;
                        }
                        else
                        {
                            GameStatus.currentSceneState = GameStatus.sceneState.pause;
                        }
                    }
                    else if (Input.mousePosition.y >= 128 && Input.mousePosition.y <= 156 && Input.mousePosition.x >= 25 && Input.mousePosition.x <= 264)
                    {
                        //print("weibo");
                        Application.OpenURL("https://weibo.com/purplemath");
                    }
                    else if (Input.mousePosition.y >= 82 && Input.mousePosition.y <= 108 && Input.mousePosition.x >= 25 && Input.mousePosition.x <= 324)
                    {
                        //print("taptap");
                        Application.OpenURL("https://www.taptap.com/developer/13027");
                    }
                    else if (Input.mousePosition.y >= 32 && Input.mousePosition.y <= 60 && Input.mousePosition.x >= 25 && Input.mousePosition.x <= 502)
                    {
                        //print("qq group");
                        Application.OpenURL("https://jq.qq.com/?_wv=1027&k=59IViO0");
                    }
                }
                //退出
                if (Input.GetKeyUp(KeyCode.Escape))
                {
                    //print("return");
                    if (GameStatus.previousSceneState == GameStatus.sceneState.title)
                    {
                        GameStatus.currentSceneState = GameStatus.sceneState.title;
                    }
                    else
                    {
                        GameStatus.currentSceneState = GameStatus.sceneState.pause;
                    }
                }
                #endregion
                break;
            case GameStatus.sceneState.title:
                #region 标题界面
                if (GameStatus.isDoubleTouched)
                {
                    if (Input.GetMouseButtonUp(1))
                    {
                        GameStatus.isDoubleTouched = false;
                        //GameStatus.textBulletList.Add(new TextBullet("双指放开", GameStatus.getBulletTextRect(4), Color.black));
                        //print("double finger up");
                    }
                }
                else
                {
                    if (Input.GetMouseButtonDown(0))
                    {
                        if(Input.mousePosition.x >= GameStatus.colorScrollBarStartX[0, 0] +
                            Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.r * 255) - 10 &&
                            Input.mousePosition.x <= GameStatus.colorScrollBarStartX[0, 0] +
                            Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.r * 255) + 38 &&
                            540 - Input.mousePosition.y >= GameStatus.colorScrollBarStartY[0, 0] - 7 &&
                            540 - Input.mousePosition.y <= GameStatus.colorScrollBarStartY[0, 0] + 35)
                        {
                            //print("back r");
                            GameStatus.changingColorId = 1;
                            GameStatus.changingColorPositionXFix = Mathf.RoundToInt(Input.mousePosition.x) - GameStatus.colorScrollBarStartX[0, 0] -
                                Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.r * 255);
                        }
                        else if (Input.mousePosition.x >= GameStatus.colorScrollBarStartX[0, 0] +
                            Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.g * 255) - 10 &&
                            Input.mousePosition.x <= GameStatus.colorScrollBarStartX[0, 0] +
                            Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.g * 255) + 38 &&
                            540 - Input.mousePosition.y >= GameStatus.colorScrollBarStartY[0, 1] - 7 &&
                            540 - Input.mousePosition.y <= GameStatus.colorScrollBarStartY[0, 1] + 35)
                        {
                            //print("back g");
                            GameStatus.changingColorId = 2;
                            GameStatus.changingColorPositionXFix = Mathf.RoundToInt(Input.mousePosition.x) - GameStatus.colorScrollBarStartX[0, 0] -
                                Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.g * 255);
                        }
                        else if (Input.mousePosition.x >= GameStatus.colorScrollBarStartX[0, 0] +
                            Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.b * 255) - 10 &&
                            Input.mousePosition.x <= GameStatus.colorScrollBarStartX[0, 0] +
                            Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.b * 255) + 38 &&
                            540 - Input.mousePosition.y >= GameStatus.colorScrollBarStartY[0, 2] - 7 &&
                            540 - Input.mousePosition.y <= GameStatus.colorScrollBarStartY[0, 2] + 35)
                        {
                            //print("back b");
                            GameStatus.changingColorId = 3;
                            GameStatus.changingColorPositionXFix = Mathf.RoundToInt(Input.mousePosition.x) - GameStatus.colorScrollBarStartX[0, 0] -
                                Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.b * 255);
                        }
                        else if (Input.mousePosition.x >= GameStatus.colorScrollBarStartX[0, 1] +
                            Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.r * 255) - 10 &&
                            Input.mousePosition.x <= GameStatus.colorScrollBarStartX[0, 1] +
                            Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.r * 255) + 38 &&
                            540 - Input.mousePosition.y >= GameStatus.colorScrollBarStartY[0, 0] - 7 &&
                            540 - Input.mousePosition.y <= GameStatus.colorScrollBarStartY[0, 0] + 35)
                        {
                            //print("front r");
                            GameStatus.changingColorId = 4;
                            GameStatus.changingColorPositionXFix = Mathf.RoundToInt(Input.mousePosition.x) - GameStatus.colorScrollBarStartX[0, 1] -
                                Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.r * 255);
                        }
                        else if (Input.mousePosition.x >= GameStatus.colorScrollBarStartX[0, 1] +
                            Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.g * 255) - 10 &&
                            Input.mousePosition.x <= GameStatus.colorScrollBarStartX[0, 1] +
                            Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.g * 255) + 38 &&
                            540 - Input.mousePosition.y >= GameStatus.colorScrollBarStartY[0, 1] - 7 &&
                            540 - Input.mousePosition.y <= GameStatus.colorScrollBarStartY[0, 1] + 35)
                        {
                            //print("front g");
                            GameStatus.changingColorId = 5;
                            GameStatus.changingColorPositionXFix = Mathf.RoundToInt(Input.mousePosition.x) - GameStatus.colorScrollBarStartX[0, 1] -
                                Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.g * 255);
                        }
                        else if (Input.mousePosition.x >= GameStatus.colorScrollBarStartX[0, 1] +
                            Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.b * 255) - 10 &&
                            Input.mousePosition.x <= GameStatus.colorScrollBarStartX[0, 1] +
                            Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.b * 255) + 38 &&
                            540 - Input.mousePosition.y >= GameStatus.colorScrollBarStartY[0, 2] - 7 &&
                            540 - Input.mousePosition.y <= GameStatus.colorScrollBarStartY[0, 2] + 35)
                        {
                            //print("front b");
                            GameStatus.changingColorId = 6;
                            GameStatus.changingColorPositionXFix = Mathf.RoundToInt(Input.mousePosition.x) - GameStatus.colorScrollBarStartX[0, 1] -
                                Mathf.RoundToInt(SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.b * 255);
                        }
                        //print(Input.mousePosition);
                        //GameStatus.refreshFrontColor();
                        //GameStatus.generateBackTex();
                        //print(GameStatus.changingColorPositionXFix);
                    }
                    else if (Input.GetMouseButton(0))
                    {
                        if(GameStatus.changingColorId == 0)
                        {
                        }
                        else if (GameStatus.changingColorId == 1)
                        {
                            SlotBank.slotArray[GameStatus.currentSlot - 1].backColor = new Color(
                                Mathf.Max(0, Mathf.Min(255, Input.mousePosition.x - GameStatus.colorScrollBarStartX[0, 0]
                                - GameStatus.changingColorPositionXFix)) / 255f,
                                SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.g,
                                SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.b);
                            GameStatus.generateFrontTex(false);
                            GameStatus.generateBackTex();
                        }
                        else if (GameStatus.changingColorId == 2)
                        {
                            SlotBank.slotArray[GameStatus.currentSlot - 1].backColor = new Color(
                                SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.r,
                                Mathf.Max(0, Mathf.Min(255, Input.mousePosition.x - GameStatus.colorScrollBarStartX[0, 0]
                                - GameStatus.changingColorPositionXFix)) / 255f,
                                SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.b);
                            GameStatus.generateFrontTex(false);
                            GameStatus.generateBackTex();
                        }
                        else if (GameStatus.changingColorId == 3)
                        {
                            SlotBank.slotArray[GameStatus.currentSlot - 1].backColor = new Color(
                                SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.r,
                                SlotBank.slotArray[GameStatus.currentSlot - 1].backColor.g,
                                Mathf.Max(0, Mathf.Min(255, Input.mousePosition.x - GameStatus.colorScrollBarStartX[0, 0]
                                - GameStatus.changingColorPositionXFix)) / 255f);
                            GameStatus.generateFrontTex(false);
                            GameStatus.generateBackTex();
                        }
                        else if (GameStatus.changingColorId == 4)
                        {
                            SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor = new Color(
                                Mathf.Max(0, Mathf.Min(255, Input.mousePosition.x - GameStatus.colorScrollBarStartX[0, 1]
                                - GameStatus.changingColorPositionXFix)) / 255f,
                                SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.g,
                                SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.b);
                            GameStatus.generateFrontTex(false);
                            GameStatus.generateBackTex();
                        }
                        else if (GameStatus.changingColorId == 5)
                        {
                            SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor = new Color(
                                SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.r,
                                Mathf.Max(0, Mathf.Min(255, Input.mousePosition.x - GameStatus.colorScrollBarStartX[0, 1]
                                - GameStatus.changingColorPositionXFix)) / 255f,
                                SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.b);
                            GameStatus.generateFrontTex(false);
                            GameStatus.generateBackTex();
                        }
                        else if (GameStatus.changingColorId == 6)
                        {
                            SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor = new Color(
                                SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.r,
                                SlotBank.slotArray[GameStatus.currentSlot - 1].frontColor.g,
                                Mathf.Max(0, Mathf.Min(255, Input.mousePosition.x - GameStatus.colorScrollBarStartX[0, 1]
                                - GameStatus.changingColorPositionXFix)) / 255f);
                            GameStatus.generateFrontTex(false);
                            GameStatus.generateBackTex();
                        }
                    }
                    else if (Input.GetMouseButtonUp(0))
                    {
                        GameStatus.changingColorId = 0;
                        checkCloseColor();
                        //继续画画
                        if (Input.mousePosition.y < 90)
                        {
                            for(int i = 1; i <= 8; i++)
                            {
                                if (Input.mousePosition.x >= (i - 1) * 120 && Input.mousePosition.x < i * 120)
                                {
                                    GameStatus.currentSlot = i;
                                    GameStatus.generateFrontTex(false);
                                    GameStatus.generateBackTex();
                                    checkCloseColor();
                                }
                            }
                        }
                        else if (Input.mousePosition.x >= 410 && Input.mousePosition.x <= 560 && Input.mousePosition.y >= 156 && Input.mousePosition.y <= 200)
                        {
                            GameStatus.generateFrontTex();
                            GameStatus.generateBackTex();
                            GameStatus.currentSceneState = GameStatus.sceneState.pause;
                        }
                        //右上角
                        else if (Input.mousePosition.y >= 465 && Input.mousePosition.y <= 540)
                        {
                            //帮助
                            if (Input.mousePosition.x >= 810 && Input.mousePosition.x <= 885)
                            {
                                GameStatus.previousSceneState = GameStatus.sceneState.title;
                                GameStatus.currentSceneState = GameStatus.sceneState.help;
                            }
                            //退出
                            else if (Input.mousePosition.x >= 886 && Input.mousePosition.x <= 960)
                            {
                                Application.Quit();
                            }
                        }
                        else
                        {
                            GameStatus.saveGame();
                        }
                    }
                    //退出
                    if (Input.GetKeyUp(KeyCode.Escape))
                    {
                        Application.Quit();
                    }
                }
                #endregion
                break;
            case GameStatus.sceneState.drawing:
                if (GameStatus.isDoubleTouched)
                {
                    if (Input.GetMouseButtonUp(1))
                    {
                        //GameStatus.textBulletList.Add(new TextBullet("双指放开", GameStatus.getBulletTextRect(4), Color.black));
                        GameStatus.isDoubleTouched = false;
                    }
                }
                else
                {
                    if (Input.GetMouseButton(1))//双击判定必须放在前面
                    {
                        GameStatus.isDoubleTouched = true;
                        SlotBank.slotArray[GameStatus.currentSlot - 1].saveMatrix();//考虑到不小心双指不同时碰到的情形
                        GameStatus.isTrueSingleTouch = false;
                        GameStatus.currentSceneState = GameStatus.sceneState.pause;
                        //print("double finger pushed");
                    }
                    else if (Input.GetMouseButtonDown(0))
                    {
                        /*if (SlotBank.slotArray[GameStatus.currentSlot - 1].matrix[Mathf.CeilToInt(Input.mousePosition.x / 15) - 1,
                            Mathf.CeilToInt(Input.mousePosition.y / 15) - 1] == 1)
                        {
                            GameStatus.isPaintingOne = false;
                        }
                        else
                        {
                            GameStatus.isPaintingOne = true;
                        }*/
                        //SlotBank.slotArray[GameStatus.currentSlot - 1].saveMatrix();//之前因为没有保底撤销队列，所以才放在了如此愚蠢的位置。
                        GameStatus.startPoint = Input.mousePosition;
                        GameStatus.isTrueSingleTouch = true;
                        //GameStatus.textBulletList.Add(new TextBullet("单指点下", GameStatus.getBulletTextRect(4), Color.black));
                    }
                    else if (Input.GetMouseButton(0))
                    {
                        if (GameStatus.isTrueSingleTouch)
                        {
                            GameStatus.endPoint = Input.mousePosition;
                            GameStatus.drawLine(GameStatus.startPoint, GameStatus.endPoint);
                            GameStatus.startPoint = Input.mousePosition;
                        }
                    }
                    else if (Input.GetMouseButtonUp(0))
                    {
                        GameStatus.forceDrawPointCD = 0f;
                        if (GameStatus.isTrueSingleTouch)
                        {
                            SlotBank.slotArray[GameStatus.currentSlot - 1].saveMatrix();
                            GameStatus.isTrueSingleTouch = false;
                            GameStatus.saveGame();
                        }
                    }
                    if (Input.GetKeyUp(KeyCode.Escape))
                    {
                        GameStatus.currentSceneState = GameStatus.sceneState.pause;
                    }
                }
                break;
            case GameStatus.sceneState.pause:
                if (GameStatus.isDoubleTouched)
                {
                    if (Input.GetMouseButtonUp(1))
                    {
                        GameStatus.isDoubleTouched = false;
                    }
                }
                else
                {
                    if (Input.GetMouseButton(1))//双击判定必须放在前面
                    {
                        GameStatus.isDoubleTouched = true;
                        GameStatus.isTrueSingleTouch = false;
                        GameStatus.currentSceneState = GameStatus.sceneState.drawing;
                    }
                    else if (Input.GetMouseButtonDown(0))
                    {
                        //GameStatus.textBulletList.Add(new TextBullet("真正的单击开始", GameStatus.getBulletTextRect(7), Color.black));
                        GameStatus.isTrueSingleTouch = true;
                    }
                    else if (Input.GetMouseButtonUp(0))
                    {
                        //print(Input.mousePosition);
                        if(Input.mousePosition.y >=281 && Input.mousePosition.y <= 314)
                        {
                            if (Input.mousePosition.x >= 196 && Input.mousePosition.x <= 335)
                            {
                                //print("undo");
                                if (GameStatus.isTrueSingleTouch)
                                {
                                    GameStatus.isTrueSingleTouch = false;
                                    if (SlotBank.slotArray[GameStatus.currentSlot - 1].undoList.Count > 1)//第一个撤销档是保底的，不能被undo
                                    {
                                        SlotBank.slotArray[GameStatus.currentSlot - 1].undo();
                                        GameStatus.saveGame();
                                        GameStatus.currentSceneState = GameStatus.sceneState.drawing;
                                    }
                                }
                            }
                            else if (Input.mousePosition.x >= 405 && Input.mousePosition.x <= 543)
                            {
                                //print("all zero");
                                if (GameStatus.isTrueSingleTouch)
                                {
                                    GameStatus.isTrueSingleTouch = false;
                                    SlotBank.slotArray[GameStatus.currentSlot - 1].saveMatrix();
                                    GameStatus.resetMatrix(0);
                                    GameStatus.saveGame();
                                    GameStatus.generateFrontTex();
                                    GameStatus.currentSceneState = GameStatus.sceneState.drawing;
                                }
                            }
                            else if (Input.mousePosition.x >= 614 && Input.mousePosition.x <= 752)
                            {
                                //print("all one");
                                if (GameStatus.isTrueSingleTouch)
                                {
                                    GameStatus.isTrueSingleTouch = false;
                                    SlotBank.slotArray[GameStatus.currentSlot - 1].saveMatrix();
                                    GameStatus.resetMatrix(1);
                                    GameStatus.saveGame();
                                    GameStatus.generateFrontTex();
                                    GameStatus.currentSceneState = GameStatus.sceneState.drawing;
                                }
                            }
                            else
                            {

                            }
                        }
                        else if(Input.mousePosition.y >= 225 && Input.mousePosition.y <= 260)
                        {
                            if (Input.mousePosition.x >= 196 && Input.mousePosition.x <= 335)
                            {
                                //print("change color");
                                //print("help");
                                GameStatus.previousSceneState = GameStatus.sceneState.pause;
                                GameStatus.currentSceneState = GameStatus.sceneState.help;
                            }
                            else if (Input.mousePosition.x >= 405 && Input.mousePosition.x <= 543)
                            {
                                //print("return title");
                                GameStatus.currentSceneState = GameStatus.sceneState.title;
                            }
                            else if (Input.mousePosition.x >= 614 && Input.mousePosition.x <= 752)
                            {
                            }
                            else
                            {

                            }
                        }
                        else if(Input.mousePosition.y >= 344 && Input.mousePosition.y <= 390)
                        {
                            if (Input.mousePosition.x >= 595 && Input.mousePosition.x <= 641)
                            {
                                GameStatus.brushSize = 1;
                            }
                            else if (Input.mousePosition.x >= 657 && Input.mousePosition.x <= 703)
                            {
                                GameStatus.brushSize = 3;
                            }
                            else if (Input.mousePosition.x >= 719 && Input.mousePosition.x <= 765)
                            {
                                GameStatus.brushSize = 5;
                            }
                            else if (Input.mousePosition.x >= 317 && Input.mousePosition.x <= 353)
                            {
                                GameStatus.isPaintingOne = false;
                            }
                            else if (Input.mousePosition.x >= 377 && Input.mousePosition.x <= 413)
                            {
                                GameStatus.isPaintingOne = true;
                            }
                            else
                            {

                            }
                        }
                        else if (540 - Input.mousePosition.y >= 370 && 540 - Input.mousePosition.y <= 430)
                        {
                            for (int i = 1; i <= 6; i++)
                            {
                                if(Input.mousePosition.x >= 160 + i * 80 && Input.mousePosition.x < 240 + i * 80)
                                {
                                    SlotBank.slotArray[GameStatus.currentSlot - 1].templateId = i;
                                    GameStatus.generateFrontTex();
                                    GameStatus.saveGame();
                                }
                            }
                        }
                        else
                        {

                        }
                    }

                    if (Input.GetKeyUp(KeyCode.Escape))
                    {
                        GameStatus.currentSceneState = GameStatus.sceneState.drawing;
                    }
                }
                break;
            default:
                break;
        }

    }

    void checkCloseColor()
    {
        if (SlotBank.slotArray[GameStatus.currentSlot - 1].isCloseColor())
        {
            GameStatus.closeColorWarningOn = true;
            GameStatus.closeColorWarningCD = 0f;
            GameStatus.closeColorWarningHasShowHint = false;
        }
        else
        {
            GameStatus.closeColorWarningOn = false;
            GameStatus.textBulletList.Clear();
        }
    }

    void closeColorWarningCircle()
    {
        if (GameStatus.closeColorWarningOn)
        {
            GameStatus.closeColorWarningCD += Time.deltaTime;
            if (GameStatus.closeColorWarningCD > 15f)
            {
                GameStatus.closeColorWarningCD -= 15f;
                GameStatus.closeColorWarningHasShowHint = false;
            }
            if (GameStatus.closeColorWarningCD > 5f)
            {
                if (GameStatus.closeColorWarningHasShowHint)
                {
                    ;
                }
                else
                {
                    GameStatus.textBulletList.Add(new TextBullet("三指触屏7次可还原默认配色", GameStatus.getBulletTextRect(13), Color.black));
                    GameStatus.closeColorWarningHasShowHint = true;
                }
            }
        }
    }
}
