﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlotBank{
    public static Slot[] slotArray = new Slot[12];

    public static void initSlotBank()
    {
        for(int i = 1; i <= 12; i++)
        {
            slotArray[i - 1] = new Slot();
        }
        resetColor();
    }

    public static void resetColor(int slotId = 0)
    {
        if (slotId == 1 || slotId == 0)
        {
            slotArray[0].backColor = new Color(0.9f, 0.9f, 1f);
            slotArray[0].frontColor = new Color(0.5f, 0.5f, 0.8f);
        }
        if (slotId == 2 || slotId == 0)
        {
            slotArray[1].backColor = new Color(1, 0.8f, 0.8f);
            slotArray[1].frontColor = new Color(0.6f, 0.4f, 0.6f);
        }
        if (slotId == 3 || slotId == 0)
        {
            slotArray[2].backColor = new Color(1, 0.8f, 0.6f);
            slotArray[2].frontColor = new Color(0.6f, 0.3f, 0.3f);
        }
        if (slotId == 4 || slotId == 0)
        {
            slotArray[3].backColor = new Color(0.8f, 0.8f, 0.8f);
            slotArray[3].frontColor = new Color(0.5f, 0.5f, 0.5f);
        }
        if (slotId == 5 || slotId == 0)
        {
            slotArray[4].backColor = new Color(0.5f, 0.5f, 0.7f);
            slotArray[4].frontColor = new Color(0.8f, 0.8f, 0.9f);
        }
        if (slotId == 6 || slotId == 0)
        {
            slotArray[5].backColor = new Color(1, 0.3f, 0.3f);
            slotArray[5].frontColor = new Color(0.5f, 0, 0);
        }
        if (slotId == 7 || slotId == 0)
        {
            slotArray[6].backColor = new Color(0, 0, 0);
            slotArray[6].frontColor = new Color(1, 1, 0);
        }
        if (slotId == 8 || slotId == 0)
        {
            slotArray[7].backColor = new Color(0, 0, 0);
            slotArray[7].frontColor = new Color(1, 1, 1);
        }
    }
}
