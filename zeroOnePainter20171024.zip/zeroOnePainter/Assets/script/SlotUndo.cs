﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlotUndo
{
    public int[,] matrix = new int[64, 36];

    public SlotUndo()
    {

    }
}
