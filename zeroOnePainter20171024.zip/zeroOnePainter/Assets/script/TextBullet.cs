﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextBullet {
    public string text = "";
    public Rect position;
    public float speed;
    public Color color;
    public int uid;

    public TextBullet(string text1, Rect position1,Color color1, float speed1 = 80f)
    {
        text = text1;
        position = position1;
        color = color1;
        speed = speed1;
        uid = GameStatus.currentTextBulletUid;
        GameStatus.currentTextBulletUid += 1;
        if (GameStatus.currentTextBulletUid > 2000)
        {
            GameStatus.currentTextBulletUid -= 2000;
        }
    }
}
